Sanna Balouchi
501154179
Assignment 2

Program runs great, all my methods work correctly.
However in the video, it only showed 2 songs from Alessia Cara being downloaded
but mine downlaods all three (as it should). I do not know if this will affect the tester.

I did keep the podcast functions/classes in the code, but I did not add it to the store.txt file
nor did i add it into the contents/store in general

Unsure if there are any spelling differences like before.

Everything works exactly the same from before, 
but with the added functions/exceptions
